Hi, this is Tomas

Before running CloneXBase, make sure you have the latest version of Spark AR installed.
After that, make sure that the Spark AR app is running. Next, you need to run CloneXBase.
Then you add your clone's 3D files and CloneX_Base automatically installs them in the desired location. 
All other processes are clearly shown in the video. All you have to do is save your filter and upload it. (with using icon.png).

That's all. Your filter will be added to Instagram after a short period of time and you will be able to use it. 

I hope it worked out for you and that you were satisfied.

For all questions: @TomasDvorak777.








CloneXBase.exe description:

14 .arproj files
14 .arexport files
5 .js files.
It's all packed in the SFX archive.

CloneX Base (Spark AR version 154).